jQuery(function($){
	var dapsdt = $('.et_pb_toggle_open');
	dapsdt.addClass('et_pb_toggle_close');
	dapsdt.removeClass('et_pb_toggle_open');
});
